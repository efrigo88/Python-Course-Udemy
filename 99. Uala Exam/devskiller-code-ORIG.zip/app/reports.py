"""
Generates vehicle sales reports based on Sqlite database.
"""

import sqlite3


class ReportGenerator:
    """
    Implement the following 4 functions:
    - sales_by_brand
    - new_customers
    - old_customers
    - next_vehicle
    """

    def __init__(self):
        self.dbname = "vehicle_crm.sqlite"
        self.con = sqlite3.connect(self.dbname)
        self.cur = self.con.cursor()

    def __del__(self):
        self.con.close()

    def sales_by_brand(self, filename):
        """
        Creates a report of vehicle sales broken by vehicle brand.
        Writes the report into a CSV file.

        Report fields:
        - vehicle_brand: vehicle brand
        - n_sales: number of sales within a group
        - total_value: sum of prices of all sales within a group

        Sort by:
        - n_sales descending
        - total_value descending

        :param str filename: Output file name
        """
        # TODO
        pass

    def new_customers(self, filename):
        """
        Creates a report of customers who purchased a new vehicle after 1st January 2020
        Writes the report into a CSV file.

        Report fields:
        - customer_name: customer name
        - vehicle_brand: brand of the last purchased vehicle
        - vehicle_model: model of the last purchased vehicle
        - vehicle_year: year of the last purchased vehicle
        - sale_dt: sale date

        Sort by:
        - customer_name ascending

        :param str filename: Output file name
        """
        # TODO
        pass

    def old_customers(self, filename):
        """
        Creates a report of customers who purchased the last vehicle before 1st January 2016
        Writes the report into a CSV file.

        Report fields:
        - customer_name: customer name
        - vehicle_brand: brand of the last purchased vehicle
        - vehicle_model: model of the last purchased vehicle
        - vehicle_year: year of the last purchased vehicle
        - sale_dt: sale date

        Sort by:
        - customer_name ascending

        :param str filename: Output file name
        """
        # TODO
        pass

    def next_vehicle(self, filename):
        """
        Creates a report of vehicles sold to customer who previously purchased another vehicle.
        Brakes the report by first vehicle brand.
        Writes the report into a CSV file.

        Report fields:
        - first_veh_brand: first vehicle brand
        - most_common_second_veh_brand: most common brand of the second vehicle purchased by the same customer
        - avg_days_between_sales: average number of days between the subsequent sales, rounded to nearest integer

        Sort by:
        - first_veh_brand ascending

        :param str filename: Output file name
        """
        # TODO
        pass
